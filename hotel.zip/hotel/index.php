<?php
    require('session.php');
    require('dbconnect.php');
    require('header.php');

$sql = "SELECT * FROM room LEFT JOIN category ON room.catid=category.catid";
$results = $conn->query($sql);
?>
    <h1>Hotel Reservation<small></small></h1>
    <div class="row">
            <table class="table table-bordered table-striped">
                <thead>
                    <th>Room ID</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Floor</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php
                    while($row = $results->fetch_assoc()) {
                    echo '<tr>
                            <td>'.$row['roomid'].'</td>
                            <td>'.$row['name'].'</td>
                            <td>'.$row['price'].'</td>
                            <td>'.$row['floor'].'</td>
                            <td><center><a href="reservationaddc.php?roomid='.$row['roomid'].'" class="btn btn-success" role="button">จองห้องพัก</a></center></td>
                        <tr>';
                    }
                    ?>
                </tbody>
            </table>
    </div>

<?php
require('footer.php');
?>
