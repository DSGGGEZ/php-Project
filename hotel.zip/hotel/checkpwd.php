<?php
    include 'session.php';
    include 'dbconnect.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $email= $_POST['email'];
        $password_2= $_POST['password_2'];

        $sql = "SELECT * FROM customer where email= '$email' and password_2 = '$password_2'";
		$query = $conn->query($sql);

        if($query->num_rows > 0){
            $row = $query->fetch_assoc();
			$_SESSION['customer'] = $row['cid'];
			header('location: index.php');
        } 
        else{
            $_SESSION['error'] = 'Customer not found';
			header('location: login.php');
        }
    }
	else{
		$_SESSION['error'] = 'Enter Customer id first';
		header('location: login.php');
    }
?>
