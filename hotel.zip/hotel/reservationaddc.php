<?php
    require('session.php');
    require('dbconnect.php');
    require('header.php');

    $cid = $_SESSION['customer'];
    $roomid = $_GET['roomid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    

    $sql = "INSERT INTO reservation(cid,roomid,checkin,checkout) VALUES (?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss',$cid,$roomid,$checkin,$checkout);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: reservation.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation | สถานะการจอง</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Hotel Reservation | สถานะการจอง<small></small></h1>

    <?php
    $cus = "select * from customer where cid = $cid";
    $cus1 = $conn->query($cus);
    $row1 = $cus1->fetch_assoc();

    $roomx = "select * from room where roomid = $roomid";
    $room = $conn->query($roomx);
    $row = $room->fetch_assoc();
    ?>
    <p>จองห้องหมายเลข.<?php echo $row['roomid']?>?</p>

    <form method="post" class="form">
        <div class="form-group">
            <label for="cid">Customer ID</label>
            <input type="text" class="form-control" name="cid" value="<?php echo $row1['fname']?> <?php echo $row1['lname']?>" disabled required>
        </div>
        <div class="form-group">
            <label for="time">Room id</label>
            <input type="text" class="form-control" name="time" value="<?php echo $row['roomid']?>" disabled required>
        </div>
        <div class="form-group">
            <label for="checkout">Checkin</label>
            <input type="date" class="form-control" name="checkout" required>
        </div>
        <div class="form-group">
            <label for="checkin">CheckOut</label>
            <input type="date" class="form-control" name="checkin" required>
        </div>
        <input class="btn btn-success" type="submit" value="จองห้อง"> 
        <a href="index.php" class="btn btn-default">ยกเลิก</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>