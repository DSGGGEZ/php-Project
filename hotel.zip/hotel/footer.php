<?php
    $conn->close();
?>
<hr>
<p class="text-center small">ยินดีต้อนรับสู่ระบบจองโรงแรม </p>
</body>
</html>