<?php
    require('session.php');
    require('dbconnect.php');
    require('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation | สถานะการจอง</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$cid = $_SESSION['customer'];

$checkin = isset($_GET['checkin']) ? $_GET['checkin'] : "";
if ($checkin != "") {
    $sql = "SELECT * FROM reservation LEFT JOIN customer ON customer.cid=reservation.cid LEFT JOIN room ON room.roomid=reservation.roomid WHERE reservation.checkin = '$checkin' AND reservation.cid='$cid'";
}
else {
    $sql = "SELECT * FROM reservation LEFT JOIN customer ON customer.cid=reservation.cid LEFT JOIN room ON room.roomid=reservation.roomid WHERE reservation.cid='$cid'";
}
    $results = $conn->query($sql);
?>

    <h1>สถานะการจอง</h1>
    <form method="get" class="form-inline">
        วันที่: &nbsp;
        <input type="date" name="checkin" class="form-control">
        <input class="btn btn-primary" type="submit" value="Filter">
    </form>

    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Reservation ID</th>
                <th>Customer ID</th>
                <th>Room ID</th>
                <th>Price</th>
                <th>Checkin</th>
                <th>Checkout</th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['resid'] ?></td>
                <td><?php echo $row['cid']?></td>
                <td><?php echo $row['roomid'] ?></td>
                <td><?php echo $row['price'] ?></td>
                <td><?php echo $row['checkin'] ?></td>
                <td><?php echo $row['checkout'] ?></td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
<?php
require('footer.php');
?>
</body>
</html>