<?php
require('lock.php');
require('../dbconnect.php');

$cid = $_GET['cid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $cid = $_POST['cid'];
    $fname = $_POST['fname'];
	$lname = $_POST['lname'];
    $email = $_POST['email'];
    $password_2 = $_POST['password_2'];
    $tel = $_POST['tel'];

    $sql = "UPDATE customer SET cid =? , fname =? , lname = ?, email = ? , password_2 = ? , tel = ?  WHERE cid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssssss',$cid,$fname,$lname,$email,$password_2,$tel,$cid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: customer.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
    <?php
        $sql = "SELECT * FROM customer WHERE cid = '$cid'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Hotel Reservation System Admin<small>Edit Customer</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="cid">Customer id</label>
            <input type="text" class="form-control" name="cid" value="<?php echo $line['cid'] ?>" required>
        </div>
        <div class="form-group">
            <label for="fname">First Name</label>
            <input type="text" class="form-control" name="fname" value="<?php echo $line['fname'] ?>" required>
        </div>
        <div class="form-group">
            <label for="lname">Last Name</label>
            <input type="text" class="form-control" name="lname" value="<?php echo $line['lname'] ?>" required>
        </div>
        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="text" name="email" class="form-control" value="<?php echo $line['email'] ?>" required>
        </div>
        <div class="form-group">
            <label for="password_2">Password</label>
            <input type="text" name="password_2" class="form-control" value="<?php echo $line['password_2'] ?>" required>
        </div>
        <div class="form-group">
            <label for="tel">Telephone No.</label>
            <input type="text" name="tel" class="form-control" value="<?php echo $line['tel'] ?>" required>
        </div>
        <input class="btn btn-success" type="submit" value="ลงทะเบียน"> 
        <a href="customer.php" class="btn btn-default">ยกเลิก</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>