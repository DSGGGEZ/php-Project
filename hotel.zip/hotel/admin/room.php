<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
    $sql = "SELECT * FROM room LEFT JOIN category ON room.catid=category.catid";
    $results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
    <h1>Hotel Reservation System Admin</h1>
    <div>
    <h4><a href="index.php" >Reservation</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="room.php" >Room</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer.php" >Customer</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="category.php" >Category<a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    <a href="roomadd.php" class="btn btn-info pull-right" style="margin-left: 10px">เพิ่มห้อง</a><h4>
    <div>
    </div>
    <br>
</div>

    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Room ID</th>
                <th>Category</th>
                <th>Price</th>
                <th>Floor</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['roomid'] ?></td>
                <td><?php echo $row['name']?></td>
                <td><?php echo $row['price'] ?></td>
                <td><?php echo $row['floor'] ?></td>
                <td class="text-center">
                    <a href="roomedit.php?roomid=<?php echo $row['roomid'] ?>" class="btn btn-sm btn-info">
                    <span class="glyphicon glyphicon-edit"></span>
                    <a href="roomdelete.php?roomid=<?php echo $row['roomid'] ?>" class="btn btn-sm btn-danger">
                    <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>
