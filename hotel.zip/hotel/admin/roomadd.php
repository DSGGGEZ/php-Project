<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $roomid = $_POST['roomid'];
    $catid = $_POST['catid'];
	$price = $_POST['price'];
    $floor = $_POST['floor'];
    

    $sql = "INSERT INTO room(roomid,catid,price,floor) VALUES (?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss',$roomid,$catid,$price,$floor);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }
    header('Location: room.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Hotel Reservation System Admin<small>add Room</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="roomid">Room id</label>
            <input type="text" class="form-control" name="roomid" required>
        </div>
        <div class="form-group">
            <label for="catid">Category</label>
            <select name="catid" class="form-control" required>
                <?php
                $catid = $conn->query('select * from category');
                while($row = $catid->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['catid'] ?>"><?php echo $row['name'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" name="price" class="form-control">
        </div>
        <div class="form-group">
            <label for="floor">Floor</label>
            <input type="text" name="floor" class="form-control">
        </div>
        <input class="btn btn-success" type="submit" value="เพิ่มห้อง"> 
        <a href="room.php" class="btn btn-default">ยกเลิก</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>