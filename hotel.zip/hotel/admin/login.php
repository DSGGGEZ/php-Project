<?php
session_start();
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the posted data
    $email = $_POST['email'];
    $password_2 = $_POST['password_2'];

    $sql = "SELECT * FROM admin WHERE email = '$email'";
	$query = $conn->query($sql);

    $row = $query->fetch_assoc();
			if($password_2 == $row['password_2']){
				$_SESSION['loggedin'] = true;
                header('Location: index.php');
                exit();
			}
			else{
				$_SESSION['error'] = 'Incorrect password';
			}

    $error = "Incorrect username/password";
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Hotel Reservation System Admin <small>Login</small></h1>

    <?php
    if (isset($error)) {
        echo '<div class="alert alert-danger" role="alert">'.$error.'</div>';
    }
    ?>

    <form method="post" class="form">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" class="form-control">
        </div>
        <div class="form-group">
            <label for="password_2">Password</label>
            <input type="password" name="password_2" class="form-control">
        </div>

        <input class="btn btn-primary" type="submit" value="Login">
    </form>

<?php
$conn->close();
?>
</body>
</html>
