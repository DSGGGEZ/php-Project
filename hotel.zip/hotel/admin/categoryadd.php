<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $catid = $_POST['catid'];
    $name = $_POST['name'];
    

    $sql = "INSERT INTO category(catid,name) VALUES (?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ss',$catid,$name);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }
    header('Location: category.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Hotel Reservation System Admin<small>Add Category</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="catid">Category id</label>
            <input type="text" class="form-control" name="catid" required>
        </div>
        <div class="form-group">
            <label for="name">Category</label>
            <input type="text" class="form-control" name="name" required>
        </div>
        <input class="btn btn-success" type="submit" value="เพิ่มประเภทห้อง"> 
        <a href="category.php" class="btn btn-default">ยกเลิก</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>