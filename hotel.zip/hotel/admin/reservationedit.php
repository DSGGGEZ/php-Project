<?php
require('lock.php');
require('../dbconnect.php');

$resid = $_GET['resid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $cid = $_POST['cid'];
    $roomid = $_POST['roomid'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];

    // Prepare sql and bind parameters
    $sql = "UPDATE reservation SET cid = ? , roomid =? , checkin = ? , checkout = ? WHERE resid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssssi', $cid,$roomid,$checkin,$checkout,$resid);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
    <?php
        $sql = "SELECT * FROM reservation LEFT JOIN customer ON customer.cid=reservation.cid LEFT JOIN room ON room.roomid=reservation.roomid where reservation.resid = '$resid'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Hotel Reservation System Admin<small>Edit Reservation</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="cid">Customer ID</label>
            <input type="text" name="cid" class="form-control" value="<?php echo $line['cid'] ?>">
        </div>
        <div class="form-group">
            <label for="roomid">Room id</label>
            <input type="text" name="roomid" class="form-control" value="<?php echo $line['roomid'] ?>">
        </div>
        <div class="form-group">
            <label for="checkin">CheckIn</label>
            <input type="text" name="checkin" class="form-control" value="<?php echo $line['checkin'] ?>">
        </div>
        <div class="form-group">
            <label for="checkout">CheckOut</label>
            <input type="text" name="checkout" class="form-control" value="<?php echo $line['checkout'] ?>">
        </div>
        <input class="btn btn-primary" type="submit" value="แก้ไขข้อมูล"> 
        <a href="index.php" class="btn btn-default">ยกเลิก</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>