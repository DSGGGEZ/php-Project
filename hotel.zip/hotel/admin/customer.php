<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
    $sql = "SELECT * FROM customer";
    $results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
    <h1>Hotel Reservation System Admin</h1>
    <div>
    <h4><a href="index.php" >Reservation</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="room.php" >Room</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer.php" >Customer</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="category.php" >Category<a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    <a href="customeradd.php" class="btn btn-info pull-right" style="margin-left: 10px">ลงทะเบียนลูกค้า</a><h4>
    <div>
    </div>
    <br>
</div>

    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Telephone No.</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['cid'] ?></td>
                <td><?php echo $row['fname']?> <?php echo $row['lname']?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['tel'] ?></td>
                <td class="text-center">
                    <a href="customeredit.php?cid=<?php echo $row['cid'] ?>" class="btn btn-sm btn-info">
                    <span class="glyphicon glyphicon-edit"></span>
                    <a href="customerdelete.php?cid=<?php echo $row['cid'] ?>" class="btn btn-sm btn-danger">
                    <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>
