<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $cid = $_POST['cid'];
    $fname = $_POST['fname'];
	$lname = $_POST['lname'];
    $email = $_POST['email'];
    $password_2 = $_POST['password_2'];
    $tel = $_POST['tel'];
    

    $sql = "INSERT INTO customer(cid,fname,lname,email,password_2,tel) VALUES (?,?,?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssssss',$cid,$fname,$lname,$email,$password_2,$tel);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }
    header('Location: customer.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Hotel Reservation System Admin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Hotel Reservation System Admin<small>Register Customer</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="cid">Customer id</label>
            <input type="text" class="form-control" name="cid" required>
        </div>
        <div class="form-group">
            <label for="fname">First Name</label>
            <input type="text" class="form-control" name="fname" required>
        </div>
        <div class="form-group">
            <label for="lname">Last Name</label>
            <input type="text" class="form-control" name="lname" required>
        </div>
        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="text" name="email" class="form-control">
        </div>
        <div class="form-group">
            <label for="password_2">Password</label>
            <input type="text" name="password_2" class="form-control">
        </div>
        <div class="form-group">
            <label for="tel">Telephone No.</label>
            <input type="text" name="tel" class="form-control">
        </div>
        <input class="btn btn-success" type="submit" value="ลงทะเบียน"> 
        <a href="customer.php" class="btn btn-default">ยกเลิก</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>