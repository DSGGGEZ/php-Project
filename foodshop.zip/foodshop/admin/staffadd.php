<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $sid = $_POST['sid'];
    $sname = $_POST['sname'];
    $sphone = $_POST['sphone'];
    $spassword = $_POST['spassword'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO staff(sid,sname,sphone,spassword) VALUES(?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss', $sid,$sname,$sphone,$spassword);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: staff.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>add Staff</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="sid">ID</label>
            <input type="text" name="sid" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="sname">Name</label>
            <input type="text" name="sname" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="sphone">Phone</label>
            <input type="text" name="sphone" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="spassword">Password</label>
            <input type="text" name="spassword" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Register"> 
        <a href="staff.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>