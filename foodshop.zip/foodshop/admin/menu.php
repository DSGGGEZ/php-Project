<?php
require('lock.php');
require('../dbconnect.php');

?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
<?php
$catid = isset($_GET['catid']) ? $_GET['catid'] : "";
if ($catid != "") {
    $sql = "SELECT * FROM product INNER JOIN category ON product.catid=category.catid where product.catid = '$catid'";
}
else {
    $sql = "SELECT * FROM product INNER JOIN category ON product.catid=category.catid";
}
$results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
            <h1>Restaurant Order System <small>Staff</small></h1>
            <h4><a href="index.php" >Order</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="menu.php" >Menu</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="tb.php" >table</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="staff.php" >staff</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="cat.php" >Category</a><h4>
            <br>
            <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
            <a href="menuadd.php" class="btn btn-primary pull-right" style="margin-left: 10px">add Menu</a>

            <form method="get" class="form-inline">
                Category: 
                <select name="catid" class="form-control">
                <option value="">All</option>
                <?php
                $tab = $conn->query('select * from category');
                while($row = $tab->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['catid'] ?>"><?php echo $row['category'] ?></option>
                    <?php
                }
                ?>
            </select>
            <input class="btn btn-primary" type="submit" value="Search">
        </form>
</div>
<div class="container-fluid">
    
    <table class="table" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Category</th>
                <th>Price</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['pid'] ?></td>
                <td><?php echo $row['pname'] ?></td>
                <td><?php echo $row['category'] ?></td>
                <td><?php echo $row['pprice'] ?></td>
                <td class="text-center">
                    <a href="menuedit.php?pid=<?php echo $row['pid'] ?>" class="btn btn-sm btn-info">
                        <span class="glyphicon glyphicon-edit"></span>
                    <a href="menudelete.php?pid=<?php echo $row['pid'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
    $conn->close();
?>
</body>
</html>
