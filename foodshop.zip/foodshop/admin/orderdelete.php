<?php
require('lock.php');
require('../dbconnect.php');

$oid = $_GET['oid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Prepare sql and bind parameters
    $sql = "delete from foodorder where oid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $oid);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>Finish Order</small></h1>

    <?php
    $sql = "select * from foodorder where oid = $oid";
    $mname = $conn->query($sql);
    $row = $mname->fetch_assoc();
    ?>
    <p>Finish Order '<?php echo $row['oid'] ?>' of Table'<?php echo $row['tid'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Finish">
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>