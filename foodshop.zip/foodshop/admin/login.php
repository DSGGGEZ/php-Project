<?php
session_start();
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $aemail = $_POST['aemail'];
    $apassword = $_POST['apassword'];

    $sql = "SELECT * FROM admin WHERE aemail = '$aemail'";
	$query = $conn->query($sql);

    $row = $query->fetch_assoc();
			if($apassword == $row['apassword']){
				$_SESSION['loggedin'] = true;
                header('Location: index.php');
                exit();
			}
			else{
				$_SESSION['error'] = 'Incorrect password';
			}

    $error = "Incorrect username/password";
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
    <div class="container">

    <h1>Restaurant Order System <small>Login</small></h1>

    <?php
    if (isset($error)) {
        echo '<div class="alert alert-danger" role="alert">'.$error.'</div>';
    }
    ?>

    <form method="post" class="form">
        <div class="form-group">
            <label for="aemail">Email</label>
            <input type="text" name="aemail" class="form-control">
        </div>
        <div class="form-group">
            <label for="apassword">Password</label>
            <input type="password" name="apassword" class="form-control">
        </div>

        <input class="btn btn-primary" type="submit" value="Login">
    </form>
    <br>

<?php
$conn->close();
?>
</div>
</body>
</html>
