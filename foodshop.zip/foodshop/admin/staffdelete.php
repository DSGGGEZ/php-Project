<?php
require('lock.php');
require('../dbconnect.php');

$sid = $_GET['sid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $sql = "delete from staff where sid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $sid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: staff.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>Delete Staff</small></h1>

    <?php
    $sql = "select sname from staff where sid = $sid";
    $mname = $conn->query($sql);
    $row = $mname->fetch_assoc();
    ?>
    <p>Delete Staff '<?php echo $row['sname'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Delete">
        <a href="staff.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>