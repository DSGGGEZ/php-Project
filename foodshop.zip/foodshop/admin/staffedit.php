<?php
require('lock.php');
require('../dbconnect.php');

$sid1 = $_GET['sid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $sid = $sid1;
    $sname = $_POST['sname'];
    $sphone = $_POST['sphone'];
    $spassword = $_POST['spassword'];

    $sql = "UPDATE staff SET sid = ? , sname =? , sphone = ? , spassword = ? WHERE sid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssss', $sid, $sname, $sphone, $spassword ,$sid1);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: staff.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "select * from staff where sid = '$sid1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Restaurant Order System: <small>Edit Staff</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="sid">ID</label>
            <input type="text" name="sid" class="form-control" value="<?php echo $line['sid'] ?>" disabled>
        </div>
        <div class="form-group">
            <label for="sname">Name</label>
            <input type="text" name="sname" class="form-control" value="<?php echo $line['sname'] ?>">
        </div>
        <div class="form-group">
            <label for="sphone">Phone</label>
            <input type="text" name="sphone" class="form-control" value="<?php echo $line['sphone'] ?>">
        </div>
        <div class="form-group">
            <label for="spassword">Password</label>
            <input type="text" name="spassword" class="form-control" value="<?php echo $line['spassword'] ?>">
        </div>
        <input class="btn btn-primary" type="submit" value="Edit Staff"> 
        <a href="staff.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>