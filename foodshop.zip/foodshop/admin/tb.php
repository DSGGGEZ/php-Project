<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
<?php
    $sql = "SELECT * FROM tablenumber";
    $results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
        <h1>Restaurant Order System <small>Table</small></h1>
        <h4><a href="index.php" >Order</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="menu.php" >Menu</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="tb.php" >table</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="staff.php" >staff</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="cat.php" >Category</a><h4>
        <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
        <a href="tbadd.php" class="btn btn-primary pull-right" style="margin-left: 10px">Add table</a>
    </div>
    <br>
</div>
<div class="row">
    <?php
        while ($row = $results->fetch_assoc()) {
            ?>
            <div class="col-sm-2 col-md-2">
                <div class="thumbnail">
                    <div class="caption text-center">
                        <h2><?php echo $row['tid'] ?></h2>
                        <h5><?php echo $row['tstatus'] ?></h5>
                        <p><a href="tbedit.php?tid=<?php echo $row['tid'] ?>" class="btn btn-primary glyphicon glyphicon-edit" role="button">
                    </a>&nbsp;&nbsp;<a href="tbdelete.php?tid=<?php echo $row['tid'] ?>" class="btn btn-danger glyphicon glyphicon-trash" role="button"></a></p>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
<?php
$conn->close();
?>
</body>
</html>
