<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $pid = $_POST['pid'];
    $catid = $_POST['catid'];
    $pname = $_POST['pname'];
    $pprice = $_POST['pprice'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO product(pid,catid,pname,pprice) VALUES(?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss', $pid,$catid,$pname,$pprice);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: menu.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>add Menu</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="pid">ID</label>
            <input type="text" name="pid" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="pname">Product Name</label>
            <input type="text" name="pname" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="sname">Category</label>
            <select name="catid" class="form-control">
                <?php
                $tab = $conn->query('select * from category');
                while($row = $tab->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['catid'] ?>"><?php echo $row['category'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="pprice">Price</label>
            <input type="text" name="pprice" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Add Menu"> 
        <a href="menu.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>