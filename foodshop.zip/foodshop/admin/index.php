<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
<?php
    $tid = isset($_GET['tid']) ? $_GET['tid'] : "";
    if ($tid != "") {
        $sql = "SELECT * FROM foodorder LEFT JOIN product ON foodorder.pid=product.pid LEFT JOIN staff ON foodorder.sid=staff.sid LEFT JOIN tablenumber ON foodorder.tid=tablenumber.tid WHERE foodorder.tid = '$tid'";
    }
    else {
        $sql = "SELECT * FROM foodorder LEFT JOIN product ON foodorder.pid=product.pid LEFT JOIN staff ON foodorder.sid=staff.sid LEFT JOIN tablenumber ON foodorder.tid=tablenumber.tid";
    }
    $results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
        <h1>Restaurant Order System <small>Order</small></h1>
        <h4><a href="index.php" >Order</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="menu.php" >Menu</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="tb.php" >table</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="staff.php" >staff</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="cat.php" >Category</a><h4>
        
        <br>
        <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
        <a href="orderadd.php" class="btn btn-primary pull-right" style="margin-left: 10px">Add Order</a>
        <form method="get" class="form-inline">
                Table : 
                <input type="text" name="tid" class="form-control" placeholder="table">
            <input class="btn btn-primary" type="submit" value="search">
        </form>
    </div>
    <br>
</div>
<div class="row">
    <?php
        while ($row = $results->fetch_assoc()) {
        ?>
            <div class="col-sm-4 col-md-2">
                <div class="thumbnail">
                    <div class="caption text-center">
                        Table
                        <h2><?php echo $row['tid'] ?></h2>
                        <h4>order : <?php echo $row['oid'] ?></h4>
                        <h5><?php echo $row['pname'] ?></h5>
                        <h5>staff : <?php echo $row['sname'] ?></h5>
                        <h5>staff : <?php echo $row['tstatus'] ?></h5>
                        <p><a href="orderdelete.php?oid=<?php echo $row['oid'] ?>" class="btn btn-success glyphicon glyphicon-check" role="button"></a></p>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>

<?php
$conn->close();
?>
</body>
</html>
