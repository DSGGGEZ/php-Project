<?php
require('lock.php');
require('../dbconnect.php');

?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
<?php
    $sql = "SELECT * FROM category";
    $results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
            <h1>Restaurant Order System <small>Category</small></h1>
            <h4><a href="index.php" >Order</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="menu.php" >Menu</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="tb.php" >table</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="staff.php" >staff</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="cat.php" >Category</a><h4>
            <br>
            <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
            <a href="catadd.php" class="btn btn-primary pull-right" style="margin-left: 10px">add Category</a>
</div>
<div class="container-fluid">
    
    <table class="table" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Category ID</th>
                <th>Category</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['catid'] ?></td>
                <td><?php echo $row['category'] ?></td>
                <td class="text-center">
                    <a href="catdelete.php?catid=<?php echo $row['catid'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
    $conn->close();
?>
</body>
</html>
