<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $tid = $_POST['tid'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO tablenumber(tid) VALUES(?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('s', $tid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: tb.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>Add Table</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="tid">Table id</label>
            <input type="text" name="tid" class="form-control">
        </div>
        <input class="btn btn-primary" type="submit" value="Add Table"> 
        <a href="tb.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?>
    <br>
</body>
</html>