<?php
require('lock.php');
require('../dbconnect.php');

$pid1 = $_GET['pid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $pid = $pid1;
    $catid = $_POST['catid'];
    $pname = $_POST['pname'];
    $pprice = $_POST['pprice'];

    $sql = "UPDATE product SET pid = ? , catid =? , pname = ? , pprice = ? WHERE pid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssss', $pid, $catid, $pname, $pprice ,$pid1);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: menu.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "select * from product where pid = '$pid1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Restaurant Order System: <small>Edit Menu</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="pid">Product ID</label>
            <input type="text" name="pid" class="form-control" value="<?php echo $line['pid'] ?>" disabled>
        </div>
        <div class="form-group">
            <label for="pname">Product Name</label>
            <input type="text" name="pname" class="form-control" value="<?php echo $line['pname'] ?>">
        </div>
        <div class="form-group">
            <label for="catid">Category</label>
            <select name="catid" class="form-control">
                <?php
                $tab = $conn->query('select * from category');
                while($row = $tab->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['catid'] ?>"><?php echo $row['category'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="pprice">Price</label>
            <input type="text" name="pprice" class="form-control" value="<?php echo $line['pprice'] ?>">
        </div>
        <input class="btn btn-primary" type="submit" value="Edit Menu"> 
        <a href="menu.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>