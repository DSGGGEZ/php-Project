<?php
require('lock.php');
require('../dbconnect.php');

$tid = $_GET['tid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $tstatus = $_POST['tstatus'];

    $sql = "UPDATE tablenumber SET tstatus =? WHERE tid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ss',$tstatus, $tid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: tb.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "select * from tablenumber where tid = '$tid'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Restaurant Order System: <small>Table edit</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="tid">Table</label>
            <input type="text" name="tid" class="form-control" value="<?php echo $line['tid'] ?>" disabled>
        </div>
        <div class="form-group">
            <label for="tstatus">Status</label>
            <select name="tstatus" class="form-control">
                <option value="waiting">waiting</option>
                <option value="completed">completed</option>
            </select>
        </div>
        <input class="btn btn-primary" type="submit" value="Edit Table"> 
        <a href="tb.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>