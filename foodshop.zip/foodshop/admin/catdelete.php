<?php
require('lock.php');
require('../dbconnect.php');

$catid = $_GET['catid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Prepare sql and bind parameters
    $sql = "delete from category where catid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $catid);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: cat.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>Delete Category</small></h1>

    <?php
    $sql = "select * from category where catid = $catid";
    $t = $conn->query($sql);
    $row = $t->fetch_assoc();
    ?>
    <p>Delete Category '<?php echo $row['category'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Delete">
        <a href="cat.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>