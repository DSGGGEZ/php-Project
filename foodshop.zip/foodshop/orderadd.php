<?php
require('dbconnect.php');
require('session.php');
$pid = $_GET['pid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $oid = $_POST['oid'];
    $sid = $_POST['sid'];
    $tid = $_POST['tid'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO foodorder(oid,pid,sid,tid) VALUES(?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss', $oid,$pid,$sid,$tid);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: orderstatus.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant Order System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Restaurant Order System: <small>add Order</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="oid">ID</label>
            <input type="text" name="oid" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="sname">Menu</label>
            <select name="pid" class="form-control">
                <?php
                $tab = $conn->query('select * from product');
                while($row = $tab->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['pid'] ?>"><?php echo $row['pname'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="sphone">Staff</label>
            <select name="sid" class="form-control">
                <?php
                $tab = $conn->query('select * from staff');
                while($row = $tab->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['sid'] ?>"><?php echo $row['sname'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="tid">Table</label>
            <select name="tid" class="form-control">
                <?php
                $tab = $conn->query('select * from tablenumber');
                while($row = $tab->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['tid'] ?>"><?php echo $row['tid'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <input class="btn btn-primary" type="submit" value="add Order"> 
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>