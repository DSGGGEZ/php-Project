<?php
require('dbconnect.php');

$rid = $_GET['rid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $sql = "delete from reservation where rid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $rid);
    $result = $statement->execute();

    $sql = "select tid from reservation where rid = $rid";
    $t = $conn->query($sql);
    $row1 = $t->fetch_assoc();
    $tid = $row1['tid'];
    $status = 'available';

    $sql = "UPDATE tableinfo SET status = ?  WHERE tid = ?";
    $st = $conn->prepare($sql);
    $st->bind_param('ss',$status ,$tid);
    $result1 = $st->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: reservation.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Delete Reservation Data</small></h1>

    <?php
    $sql = "select rid from reservation where rid = $rid";
    $mname = $conn->query($sql);
    $row = $mname->fetch_assoc();
    ?>
    <p>Delete reservation Number '<?php echo $row['rid'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Delete">
        <a href="reservation.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>