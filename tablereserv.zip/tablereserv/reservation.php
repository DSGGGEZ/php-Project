<?php
    require('session.php');
    require('dbconnect.php');
    require('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$mid=$_SESSION['member'];
    $sql = "SELECT * FROM reservation INNER JOIN tableinfo ON reservation.tid=tableinfo.tid INNER JOIN member ON reservation.mid=member.mid INNER JOIN package ON reservation.pid=package.pid WHERE reservation.mid = '$mid'";

$results = $conn->query($sql);
?>
<div class="container">
    <h1>Reservation</h1>
    <table class="table" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Reservation Number</th>
                <th>Table Number</th>
                <th>Package</th>
                <th>Member Name</th>
                <th>Seat</th>
                <th>Reservation Time</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['rid'] ?></td>
                <td><?php echo $row['tline'] ?></td>
                <td><?php echo $row['pname'] ?></td>
                <td><?php echo $row['mname'] ?></td>
                <td><?php echo $row['seat'] ?></td>
                <td><?php echo $row['reservtime'] ?></td>
                <td class="text-center">
                    <a href="resdelete.php?rid=<?php echo $row['rid'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    </div>
<?php
require('footer.php');
?>
</body>
</html>