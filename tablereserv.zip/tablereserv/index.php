<?php
    require('session.php');
    require('dbconnect.php');
    require('header.php');

    $sql = "SELECT * FROM tableinfo";
    $results = $conn->query($sql);
?>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <h1>Table</h1>
        </div>
    <br>
</div>
<div class="row">
    <?php
        while ($row = $results->fetch_assoc()) {
            ?>
            <div class="col-sm-2 col-md-2">
                <div class="thumbnail">
                    <div class="caption text-center">
                        <h2><?php echo $row['tline'] ?></h2>
                        <h5><?php echo $row['status'] ?></h5>
                        <p><a href="reserve.php?tid=<?php echo $row['tid'] ?>" class="btn btn-success glyphicon glyphicon-check" role="button"></a></p>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
<?php
require('footer.php');
?>
</body>
</html>