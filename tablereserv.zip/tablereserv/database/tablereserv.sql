-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2022 at 05:50 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tablereserv`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `aname` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `aemail` text COLLATE utf8_unicode_ci NOT NULL,
  `apassword` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `aname`, `aemail`, `apassword`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `mid` int(11) NOT NULL,
  `mname` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `memail` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `mpassword` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mid`, `mname`, `memail`, `mpassword`) VALUES
(1, 'Vachirapon Tosawat', 'indonateCS@gmail.com', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `pid` int(11) NOT NULL,
  `pname` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `detail` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`pid`, `pname`, `detail`, `price`) VALUES
(1, 'หมูอิ่มคุ้ม', '- หมูทุกอย่าง - เครื่องดื่ม refill', '189'),
(2, 'ซีฟูีดทะเลเดือด', '- หมูทุกอย่าง- ซีฟู๊ด- เครื่องดื้ม', '289');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `rid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `seat` int(11) DEFAULT NULL,
  `reservtime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tableinfo`
--

CREATE TABLE `tableinfo` (
  `tid` int(11) NOT NULL,
  `tline` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tableinfo`
--

INSERT INTO `tableinfo` (`tid`, `tline`, `status`) VALUES
(1, 'A1', 'reserved'),
(2, 'A2', 'available'),
(3, 'A3', 'available'),
(4, 'A4', 'available'),
(5, 'A5', 'available'),
(6, 'A6', 'reserved'),
(7, 'B1', 'reserved'),
(8, 'B2', 'available'),
(9, 'B3', 'available'),
(10, 'B4', 'available'),
(11, 'B5', 'available'),
(12, 'B6', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `walkin`
--

CREATE TABLE `walkin` (
  `wid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `seat` int(11) DEFAULT NULL,
  `walkintime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `FK_package_TO_reservation` (`pid`),
  ADD KEY `FK_member_TO_reservation` (`mid`),
  ADD KEY `FK_tableinfo_TO_reservation` (`tid`);

--
-- Indexes for table `tableinfo`
--
ALTER TABLE `tableinfo`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `walkin`
--
ALTER TABLE `walkin`
  ADD PRIMARY KEY (`wid`),
  ADD KEY `FK_member_TO_walkin` (`mid`),
  ADD KEY `FK_package_TO_walkin` (`pid`),
  ADD KEY `FK_tableinfo_TO_walkin` (`tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `walkin`
--
ALTER TABLE `walkin`
  MODIFY `wid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `FK_member_TO_reservation` FOREIGN KEY (`mid`) REFERENCES `member` (`mid`),
  ADD CONSTRAINT `FK_package_TO_reservation` FOREIGN KEY (`pid`) REFERENCES `package` (`pid`),
  ADD CONSTRAINT `FK_tableinfo_TO_reservation` FOREIGN KEY (`tid`) REFERENCES `tableinfo` (`tid`);

--
-- Constraints for table `walkin`
--
ALTER TABLE `walkin`
  ADD CONSTRAINT `FK_member_TO_walkin` FOREIGN KEY (`mid`) REFERENCES `member` (`mid`),
  ADD CONSTRAINT `FK_package_TO_walkin` FOREIGN KEY (`pid`) REFERENCES `package` (`pid`),
  ADD CONSTRAINT `FK_tableinfo_TO_walkin` FOREIGN KEY (`tid`) REFERENCES `tableinfo` (`tid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
