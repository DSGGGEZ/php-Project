<?php
require('dbconnect.php');
require('session.php');

$tid = $_GET['tid'];
$mid = $_SESSION['member'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $rid = $_POST['rid'];
    $pid = $_POST['pid'];
    $seat = $_POST['seat'];
    $reservtime = $_POST['reservtime'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO reservation(rid,tid,pid,mid,seat,reservtime) VALUES(?,?,?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssssss', $rid,$tid,$pid,$mid,$seat,$reservtime);
    $result = $statement->execute();

    $status = 'reserved';

    $sql = "UPDATE tableinfo SET status = ?  WHERE tid = ?";
    $st = $conn->prepare($sql);
    $st->bind_param('ss',$status ,$tid);
    $result1 = $st->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Table Reserve</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="mid">Member id</label>
            <input type="text" name="mid" class="form-control" value="<?php echo $tid?>" require disabled>
        </div>
        <div class="form-group">
            <label for="tid">Table</label>
            <input type="text" name="tid" class="form-control" value="<?php echo $tid?>" require disabled> 
        </div>
        <div class="form-group">
            <label for="pid">Package</label>
            <select name="pid" class="form-control">
                <?php
                $pn = $conn->query('select pid, pname from package');
                while($row = $pn->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['pid'] ?>"><?php echo $row['pname'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="seat">Seat</label>
            <input type="text" name="seat" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="reservtime">Reserve time</label>
            <input type="time" name="reservtime" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Reserve"> 
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>