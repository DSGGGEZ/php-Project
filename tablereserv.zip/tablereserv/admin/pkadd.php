<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $pid = $_POST['pid'];
    $pname = $_POST['pname'];
    $detail = $_POST['detail'];
    $price = $_POST['price'];

    $sql = "INSERT INTO package(pid,pname,detail,price) VALUES(?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss', $pid,$pname,$detail,$price);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: pk.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
  background-color:black
}
body {
    background-color:#241B44;
}
div{
    background-color:white;
}
</style>
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Add Package</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="pid">Package id</label>
            <input type="text" name="pid" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="pname">Package Name</label>
            <input type="text" name="pname" class="form-control" require >
        </div>
        <div class="form-group">
            <label for="detail">Detail</label>
            <input type="text" name="detail" class="form-control" require >
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" name="price" class="form-control" require >
        </div>
        <input class="btn btn-primary" type="submit" value="Add Package"> 
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?>
    <br>
</body>
</html>