<?php
require('lock.php');
require('../dbconnect.php');

$rid = $_GET['rid'];
$sql = "SELECT * FROM reservation INNER JOIN tableinfo ON reservation.tid=tableinfo.tid INNER JOIN member ON reservation.mid=member.mid INNER JOIN package ON reservation.pid=package.pid where reservation.rid = $rid";
    $dt = $conn->query($sql);
    $line = $dt->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $tid = $line['tid'];
    $pid = $line['pid'];
    $mid = $line['mid'];
    $seat = $line['seat'];
    $walkintime = $_POST['walkintime'];

    $sql = "INSERT INTO walkin(wid,tid,pid,mid,seat,walkintime) VALUES(?,?,?,?,?,?)";
    $st = $conn->prepare($sql);
    $st->bind_param('ssssss', $wid,$tid,$pid,$mid,$seat,$walkintime);
    $result1 = $st->execute();

    $sql = "delete from reservation where rid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $rid);
    $result = $statement->execute();

    

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: res.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Delete Reservation Data</small></h1>

    <?php
    
    ?>
    <p>Walkin from reservation Number '<?php echo $line['rid'] ?>'?</p>

    <form method="post" class="form">
        <div class="form-group">
            <label for="tid">Table</label>
            <input type="text" name="mid" class="form-control" value="<?php echo $line['tline'] ?>" require>
        </div>
        <div class="form-group">
            <label for="pid">Package</label>
            <input type="text" name="mid" class="form-control" value="<?php echo $line['pname'] ?>" require>
        </div>
        <div class="form-group">
            <label for="mid">Member id</label>
            <input type="text" name="mid" class="form-control" value="<?php echo $line['mid'] ?>" require>
        </div>
        <div class="form-group">
            <label for="seat">Seat</label>
            <input type="text" name="seat" class="form-control" value="<?php echo $line['seat'] ?>" require>
        </div>
        <div class="form-group">
            <label for="walkintime">Walkin time</label>
            <input type="time" name="walkintime" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Walkin"> 
        <a href="cn.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>