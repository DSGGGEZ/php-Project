<?php
require('lock.php');
require('../dbconnect.php');

$mid1 = $_GET['mid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $mid = $mid1;
    $mname = $_POST['mname'];
    $memail = $_POST['memail'];
    $mpassword = $_POST['mpassword'];

    $sql = "UPDATE member SET mid = ? , mname =? , memail = ? , mpassword = ? WHERE mid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssss', $mid, $mname, $memail, $mpassword ,$mid1);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: member.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "select * from member where mid = '$mid1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Aye Shabu Table Reservation: <small>Edit Member</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="mid">ID</label>
            <input type="text" name="mid" class="form-control" value="<?php echo $line['mid'] ?>" disabled>
        </div>
        <div class="form-group">
            <label for="mname">Name</label>
            <input type="text" name="mname" class="form-control" value="<?php echo $line['mname'] ?>">
        </div>
        <div class="form-group">
            <label for="memail">Email</label>
            <input type="text" name="memail" class="form-control" value="<?php echo $line['memail'] ?>">
        </div>
        <div class="form-group">
            <label for="mpassword">Password</label>
            <input type="text" name="mpassword" class="form-control" value="<?php echo $line['mpassword'] ?>">
        </div>
        <input class="btn btn-primary" type="submit" value="Edit Member"> 
        <a href="member.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>