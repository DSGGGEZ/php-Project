<?php
require('lock.php');
require('../dbconnect.php');

$tid = $_GET['tid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $tline = $_POST['tline'];
    $status = $_POST['status'];

    $sql = "UPDATE tableinfo SET tline = ? , status =? WHERE tid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss', $tline, $status, $tid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "select * from tableinfo where tid = '$tid'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Aye Shabu Table Reservation: <small>Table edit</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="tline">Table Line</label>
            <input type="text" name="tline" class="form-control" value="<?php echo $line['tline'] ?>" >
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" class="form-control">
                <option value="available">available</option>
                <option value="reserved">reserved</option>
            </select>
        </div>
        <input class="btn btn-primary" type="submit" value="Edit Table"> 
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>