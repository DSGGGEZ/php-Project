<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>DSG's Gameshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        /* Dropdown Button */
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 10px;
  font-size: 10px;
  border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  font-size: 12px;
  text-decoration: none;
  display: block;
}
body {
    background-color:#241B44;
}
div{
    background-color:white;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}
    </style>
</head>
<body class="container">
    <nav class="navbar navbar-default">
    <div class="container-fluid">
    <h1>DSG's Gameshop Admin </h1>
    <h4><a href="member.php" >Member</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php" >Product</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="other.php" >Other</a><h4>
    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    
    <div class="dropdown">
        <button class="dropbtn">Add Data</button>
        <div class="dropdown-content">
            <a href="addmember.php" >Add Member</a>
            <a href="addproduct.php" >Add Product</a>
            <a href="addcom.php" >Add Devcompany</a>
            <a href="addtype.php" >Add GameType</a>
            <a href="addplatform.php" >Add Platform</a>
        
        </div>
    </div>
</div>
<?php
        $sql1 = "SELECT * FROM devcompany";
        $results1 = $conn->query($sql1);
?>
<div>
    <div class="container-fluid">
    <h3>Devcompany<a href="addcom.php" class="btn btn-success pull-right" style="margin-left: 10px">add Devcompany</a></h3>
    </div>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>id</th>
                <th>Devcompany name</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row1 = $results1->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row1['iddevcompany'] ?></td>
                <td><?php echo $row1['devcompanyname'] ?></td>
                <td class="text-center">
                    <a href="deletecom.php?iddevcompany=<?php echo $row1['iddevcompany'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    <?php
        $sql2 = "SELECT * FROM gametype";
        $results2 = $conn->query($sql2);
    ?>
    <div class="container-fluid">
    <h3>Gametype<a href="addtype.php" class="btn btn-success pull-right" style="margin-left: 10px">add Gametype</a></h3>
    </div>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>id</th>
                <th>gametype</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row2 = $results2->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row2['idgametype'] ?></td>
                <td><?php echo $row2['gametype'] ?></td>
                <td class="text-center">
                    <a href="deletetype.php?idgametype=<?php echo $row2['idgametype'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    <?php
        $sql3 = "SELECT * FROM platform";
        $results3 = $conn->query($sql3);
    ?>
    <div class="container-fluid">
    <h3>Platform<a href="addplatform.php" class="btn btn-success pull-right" style="margin-left: 10px">add Platform</a></h3>
    </div>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>id</th>
                <th>Platform</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row3 = $results3->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row3['idplatform'] ?></td>
                <td><?php echo $row3['platformname'] ?></td>
                <td class="text-center">
                    <a href="deleteplatform.php?idplatform=<?php echo $row3['idplatform'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
    </div>

<?php
$conn->close();

?>
<script type="text/javascript" src="js/bootstrap/bootstrap-dropdown.js"></script>
<script>
$('.dropdown-toggle').dropdown()
</script>
</body>
</html>
