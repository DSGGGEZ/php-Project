<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $mid = $_POST['mid'];
    $mname = $_POST['mname'];
    $memail = $_POST['memail'];
    $mpassword = $_POST['mpassword'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO member(mid,mname,memail,mpassword) VALUES(?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss', $mid,$mname,$memail,$mpassword);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: member.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Registerations</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="mid">ID</label>
            <input type="text" name="mid" class="form-control">
        </div>
        <div class="form-group">
            <label for="mname">Name</label>
            <input type="text" name="mname" class="form-control">
        </div>
        <div class="form-group">
            <label for="memail">Email</label>
            <input type="text" name="memail" class="form-control">
        </div>
        <div class="form-group">
            <label for="mpassword">Password</label>
            <input type="text" name="mpassword" class="form-control">
        </div>
        <input class="btn btn-primary" type="submit" value="Register"> 
        <a href="member.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>