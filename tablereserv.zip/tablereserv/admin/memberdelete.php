<?php
require('lock.php');
require('../dbconnect.php');

$mid = $_GET['mid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $sql = "delete from member where mid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $mid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: member.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Delete Member</small></h1>

    <?php
    $sql = "select mname from member where mid = $mid";
    $mname = $conn->query($sql);
    $row = $mname->fetch_assoc();
    ?>
    <p>Delete Member '<?php echo $row['mname'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Delete">
        <a href="member.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>