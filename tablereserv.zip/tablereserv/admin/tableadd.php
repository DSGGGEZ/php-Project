<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $tid = $_POST['tid'];
    $tline = $_POST['tline'];

    // Prepare sql and bind parameters
    $sql = "INSERT INTO tableinfo(tid,tline) VALUES(?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ss', $tid,$tline);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
  background-color:black
}
body {
    background-color:#241B44;
}
div{
    background-color:white;
}
</style>
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Add Table</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="tid">Table id</label>
            <input type="text" name="tid" class="form-control">
        </div>
        <div class="form-group">
            <label for="tline">Table Line</label>
            <input type="text" name="tline" class="form-control">
        </div>
        <input class="btn btn-primary" type="submit" value="Add Table"> 
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?>
    <br>
</body>
</html>