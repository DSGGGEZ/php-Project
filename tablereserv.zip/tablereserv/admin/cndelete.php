<?php
require('lock.php');
require('../dbconnect.php');

$wid = $_GET['wid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $sql = "delete from walkin where wid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $wid);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: cn.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">

    <h1>Aye Shabu Table Reservation: <small>Delete Walkin</small></h1>

    <?php
    $sql = "select wid from walkin where wid = $wid";
    $mname = $conn->query($sql);
    $row = $mname->fetch_assoc();
    ?>
    <p>Delete walkin Number '<?php echo $row['wid'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Delete">
        <a href="cn.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?><br>
</body>
</html>