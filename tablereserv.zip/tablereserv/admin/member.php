<?php
require('lock.php');
require('../dbconnect.php');

?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
<?php
$mname = isset($_GET['mname']) ? $_GET['mname'] : "";
if ($mname != "") {
    $sql = "SELECT * FROM member where mname = '$mname'";
}
else {
    $sql = "SELECT * FROM member";
}
$results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
            <h1>Aye Shabu Table Reservation <small>Table</small></h1>
            <h4><a href="index.php" >Table</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="res.php" >Reservation</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="cn.php" >CheckIn</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="member.php" >Member</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="pk.php" >Package</a><h4>
            <br>
            <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
            <a href="memberadd.php" class="btn btn-primary pull-right" style="margin-left: 10px">Register</a>

            <form method="get" class="form-inline">
                Member name: 
                <input type="text" name="mname" class="form-control" placeholder="member name">
            <input class="btn btn-primary" type="submit" value="ค้นหา">
        </form>
</div>
<div class="container-fluid">
    
    <table class="table" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Member ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['mid'] ?></td>
                <td><?php echo $row['mname'] ?></td>
                <td><?php echo $row['memail'] ?></td>
                <td><?php echo $row['mpassword'] ?></td>
                <td class="text-center">
                    <a href="memberedit.php?mid=<?php echo $row['mid'] ?>" class="btn btn-sm btn-info">
                        <span class="glyphicon glyphicon-edit"></span>
                    <a href="memberdelete.php?mid=<?php echo $row['mid'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
    $conn->close();
?>
</body>
</html>
