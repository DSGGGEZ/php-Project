<?php
require('lock.php');
require('../dbconnect.php');

?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container" >
<?php
$pid = isset($_GET['pid']) ? $_GET['pid'] : "";
$mid = isset($_GET['mid']) ? $_GET['mid'] : "";
if ($pid != "" && $mid) {
    $sql = "SELECT * FROM walkin INNER JOIN tableinfo ON walkin.tid=tableinfo.tid INNER JOIN member ON walkin.mid=member.mid INNER JOIN package ON walkin.pid=package.pid  WHERE walkin.pid = '$pid' AND walkin.mid = '$mid'";
}
else if ($pid != "") {
    $sql = "SELECT * FROM walkin INNER JOIN tableinfo ON walkin.tid=tableinfo.tid INNER JOIN member ON walkin.mid=member.mid INNER JOIN package ON walkin.pid=package.pid  WHERE walkin.pid = '$pid'";
}
else if ($mid != "") {
    $sql = "SELECT * FROM walkin INNER JOIN tableinfo ON walkin.tid=tableinfo.tid INNER JOIN member ON walkin.mid=member.mid INNER JOIN package ON walkin.pid=package.pid  WHERE walkin.mid = '$mid'";
}
else {
    $sql = "SELECT * FROM walkin INNER JOIN tableinfo ON walkin.tid=tableinfo.tid INNER JOIN member ON walkin.mid=member.mid INNER JOIN package ON walkin.pid=package.pid";
}
$results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
            <h1>Aye Shabu Table Reservation <small>Table</small></h1>
            <h4><a href="index.php" >Table</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="res.php" >Reservation</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="cn.php" >CheckIn</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="member.php" >Member</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="pk.php" >Package</a><h4>
            <br>
            <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
            <a href="resadd.php" class="btn btn-primary pull-right" style="margin-left: 10px">Walkin</a>
            <form method="get" class="form-inline">
            Package ID: 
            <input type="text" name="pid" class="form-control" placeholder="package id">
            Member ID: 
            <input type="text" name="mid" class="form-control" placeholder="member id">
            <input class="btn btn-primary" type="submit" value="ค้นหา">
        </form>
</div>
<div class="container-fluid">
    
    <table class="table" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Walkin Number</th>
                <th>Table Number</th>
                <th>Package</th>
                <th>Member Name</th>
                <th>Seat</th>
                <th>Walkin Time</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['wid'] ?></td>
                <td><?php echo $row['tline'] ?></td>
                <td><?php echo $row['pname'] ?></td>
                <td><?php echo $row['mname'] ?></td>
                <td><?php echo $row['seat'] ?></td>
                <td><?php echo $row['walkintime'] ?></td>
                <td class="text-center">
                    <a href="cndelete.php?wid=<?php echo $row['wid'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();

?>

</body>
</html>
