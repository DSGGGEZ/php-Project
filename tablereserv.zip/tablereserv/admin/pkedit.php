<?php
require('lock.php');
require('../dbconnect.php');

$pid1 = $_GET['pid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $pid = $_POST['pid'];
    $pname = $_POST['pname'];
    $detail = $_POST['detail'];
    $price = $_POST['price'];

    $sql = "UPDATE package SET pid = ? , pname =? , detail = ? , price = ? WHERE pid = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssss', $pid, $pname, $detail,$price,$pid1);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: pk.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Aye Shabu Table Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "select * from package where pid = '$pid1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Aye Shabu Table Reservation: <small>Package edit</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="pid">Package id</label>
            <input type="text" name="pid" class="form-control" value="<?php echo $line['pid'] ?>" require>
        </div>
        <div class="form-group">
            <label for="pname">Package Name</label>
            <input type="text" name="pname" class="form-control" value="<?php echo $line['pname'] ?>" require>
        </div>
        <div class="form-group">
            <label for="detail">Detail</label>
            <input type="text" name="detail" class="form-control" value="<?php echo $line['detail'] ?>" require>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" name="price" class="form-control" value="<?php echo $line['price'] ?>" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Edit Package"> 
        <a href="pk.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>