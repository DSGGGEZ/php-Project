<!doctype html>
<html lang="en">
    <head>
    <title>DSG's Gameshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
    background-color:#241B44;
    }
    div{
    background-color:white;
    }
    </style>
</head>
 <body class="container">
<div class="container">
 <h1>Member <small>Login</small></h1>
  <form method="post" class="form" action="checkpwd.php">
    <div class="form-group">
        <label for="gid">Member ID</label>
        <input type="text" name="mid" class="form-control" placeholder="member id"></div>
    <div class="form-group">
        <label for="gid">Password</label>
        <input type="password" name="mpassword" class="form-control" placeholder="password">
    </div>
    <input type="submit" class="btn btn-primary" value="Login">
    <a href="index.php" class="btn btn-danger">Cancel</a>
  </form>
  <br>
</div>
 </body>
</html>
