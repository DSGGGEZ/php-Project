<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>DSG's Gameshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        /* Dropdown Button */
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 10px;
  font-size: 10px;
  border: none;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  font-size: 12px;
  text-decoration: none;
  display: block;
}
body {
    background-color:#241B44;
}
div{
    background-color:white;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {display: block;}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {background-color: #3e8e41;}
    </style>
</head>
<body class="container">
<?php
    $mid = isset($_GET['mid']) ? $_GET['mid'] : "";
    if ($mid != "") {
        $sql = "SELECT * FROM member WHERE mid='$mid' ORDER BY mid";
    }
    else {
        $sql = "SELECT * FROM member ORDER BY mid";
    }
    $results = $conn->query($sql);
?>
    <nav class="navbar navbar-default">
    <div class="container-fluid">
    <h1>DSG's Gameshop Admin </h1>
    <h4><a href="member.php" >Member</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php" >Product</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="other.php" >Other</a><h4>
    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    
    <div class="dropdown">
        <button class="dropbtn">Add Data</button>
        <div class="dropdown-content">
            <a href="addmember.php" >Add Member</a>
            <a href="addproduct.php" >Add Product</a>
            <a href="addcom.php" >Add Devcompany</a>
            <a href="addtype.php" >Add GameType</a>
            <a href="addplatform.php" >Add Platform</a>
        
        </div>
    </div>
</div>

<form method="get" class="form-inline">
&nbsp;&nbsp;&nbsp;&nbsp;Member id: &nbsp;
        <input type="text" name="mid" class="form-control" placeholder="member id">
        <input class="btn btn-primary" type="submit" value="Filter">
    </form>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>MID</th>
                <th>name</th>
                <th>Address</th>
                <th>Balance</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td>
                    <img src="../images/U01.jpg"  style="width: 30px; height: 30px; object-fit: cover;">
                    <?php echo $row['mid'] ?>
                </td>
                <td><?php echo $row['mname'] ?></td>
                <td><?php echo $row['address'] ?></td>
                <td><?php echo $row['balance'] ?></td>
                <td class="text-center">
                    <a href="editmember.php?idmember=<?php echo $row['idmember'] ?>" class="btn btn-sm btn-info">
                        <span class="glyphicon glyphicon-edit"></span>
                    <a href="deletemember.php?idmember=<?php echo $row['idmember'] ?>" class="btn btn-sm btn-danger">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();

?>
<script type="text/javascript" src="js/bootstrap/bootstrap-dropdown.js"></script>
<script>
$('.dropdown-toggle').dropdown()
</script>
</body>
</html>
