<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $idbrand = $_POST['idbrand'];
    $idcolor = $_POST['idcolor'];
    $idcartype = $_POST['idcartype'];
    $carname = $_POST['carname'];
    $price = $_POST['price'];

    // Prepare sql and bind parameters
    $sql = "insert into car (idbrand, idcolor, idcartype , carname, price ) values (?, ?, ?, ?, ?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssss', $idbrand, $idcolor , $idcartype, $carname, $price );
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Carshop: <small>Add Car</small></h1>
    

    <form method="post" class="form">
        <div class="form-group">
            <label for="idbrand">Brand</label>
            <select name="idbrand" class="form-control">
                <?php
                $tb = $conn->query('select idbrand, brand from brand');
                while($row = $tb->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idbrand'] ?>"><?php echo $row['brand'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="idcolor">Color</label>
            <select name="idcolor" class="form-control">
                <?php
                $categories = $conn->query('select idcolor, color from color');
                while($row = $categories->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idcolor'] ?>"><?php echo $row['color'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="idcartype">Cartype</label>
            <select name="idcartype" class="form-control">
                <?php
                $categories = $conn->query('select idcartype, cartype from cartype');
                while($row = $categories->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idcartype'] ?>"><?php echo $row['cartype'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="carname">Carname</label>
            <input type="text" name="carname" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" name="price" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="index.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>