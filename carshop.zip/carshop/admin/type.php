<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
    $sql = "SELECT * FROM cartype";
$results = $conn->query($sql);
?>

    <h1>Carshop Admin <small>Cartype</small></h1>

    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    <a href="coloradd.php" class="btn btn-primary pull-right">Add Color</a>
    <h4><a href="index.php" >Cars</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="brand.php" >Brand</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="type.php" >Cartype</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="color.php" >Color</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="sc.php" >Sold car</a>
    <br><br>

    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>ID Cartype</th>
                <th>Cartype</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['idcartype'] ?></td>
                <td><?php echo $row['cartype'] ?></td>
                <td class="text-center">
                    <a href="typeedit.php?idcartype=<?php echo $row['idcartype'] ?>" class="btn btn-sm btn btn-info">
                        <span class="glyphicon glyphicon-edit "></span>
                    </a>
                    <a href="typedelete.php?idcartype=<?php echo $row['idcartype'] ?>" class="btn btn-sm btn btn-danger">
                        <span class="glyphicon glyphicon-trash "></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>