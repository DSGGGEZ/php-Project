<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $idbrand = $_POST['idbrand'];
    $brand = $_POST['brand'];

    $sql = "insert into brand (idbrand, brand) values (?, ?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ss', $idbrand, $brand);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: brand.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Carshop: <small>Add Brand</small></h1>
    

    <form method="post" class="form">
        <div class="form-group">
            <label for="idbrand">Brand ID</label>
            <input type="text" name="idbrand" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="brand">Brand</label>
            <input type="text" name="brand" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="brand.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>