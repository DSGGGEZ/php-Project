<?php
require('lock.php');
require('../dbconnect.php');

$idcolor = $_GET['idcolor'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $color = $_POST['color'];
    
    $sql = "UPDATE color SET  idcolor =? , color = ?   WHERE idcolor = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss',$idcolor, $color,$idcolor );
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: color.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Car shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "SELECT * FROM color WHERE idcolor = '$idcolor'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Car shop<small>Edit car</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="idcolor">Color ID</label>
            <input type="text" name="idcolor" class="form-control" value="<?php echo $line['idcolor']?>"  require>
        </div>
        <div class="form-group">
            <label for="color">Color</label>
            <input type="text" name="color" class="form-control" value="<?php echo $line['color']?>"  require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="color.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>