<?php
require('lock.php');
require('../dbconnect.php');

$idbrand = $_GET['idbrand'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $brand = $_POST['brand'];
   
    $sql = "UPDATE brand SET idbrand = ? , brand =? WHERE idbrand = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss',$idbrand, $brand, $idbrand);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: brand.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Car shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "SELECT * FROM brand WHERE idbrand = '$idbrand'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Car shop<small>Edit Brand</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="idbrand">Brand ID</label>
            <input type="text" name="idbrand" class="form-control" value="<?php echo $line['idbrand']?>"  require>
        </div>
        <div class="form-group">
            <label for="brand">Brand</label>
            <input type="text" name="brand" class="form-control" value="<?php echo $line['brand']?>"  require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="brand.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>