<?php
require('lock.php');
require('../dbconnect.php');

$idcartype = $_GET['idcartype'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $cartype = $_POST['cartype'];

    $sql = "UPDATE car SET , idcartype = ? ,cartype = ?  WHERE idcartype = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss',$idcartype, $cartype ,$idcartype);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Car shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "SELECT * FROM cartype WHERE idcartype = '$idcartype'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Car shop<small>Edit cartype</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="idcartype">Cartype ID</label>
            <input type="text" name="idcartype" class="form-control" value="<?php echo $line['idcartype']?>"  require>
        </div>
        <div class="form-group">
            <label for="cartype">Cartype</label>
            <input type="text" name="cartype" class="form-control" value="<?php echo $line['cartype']?>"  require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="type.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>