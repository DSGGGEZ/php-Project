<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $customername = $_POST['customername'];
    $idcar = $_POST['idcar'];
    $sold_date = date('Y-m-d');

    $sql = "insert into sold_car (customername,idcar,sold_date) values (?, ?, ?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss', $customername , $idcar,  $sold_date );
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: sc.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Carshop: <small>Sell Car</small></h1>
    

    <form method="post" class="form">
    <div class="form-group">
            <label for="customername">Customer Name</label>
            <input type="text" name="customername" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="idcar">Car</label>
            <select name="idcar" class="form-control">
                <?php
                $tb = $conn->query('select idcar, carname from car');
                while($row = $tb->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idcar'] ?>"><?php echo $row['carname'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="sold_date">Date</label>
            <input type="date" name="sold_date" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="sc.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>