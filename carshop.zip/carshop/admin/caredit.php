<?php
require('lock.php');
require('../dbconnect.php');

$idcar1 = $_GET['idcar'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    
    $idbrand = $_POST['idbrand'];
    $idcolor = $_POST['idcolor'];
    $idcartype = $_POST['idcartype'];
    $carname = $_POST['carname'];
    $price = $_POST['price'];

    // Prepare sql and bind parameters
    $sql = "UPDATE car SET idbrand = ? , idcolor =? , idcartype = ? , carname = ? , price = ?  WHERE idcar = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssssss',$idbrand, $idcolor, $idcartype, $carname, $price,  $idcar1);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Car shop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<div class="container-fluid">
    <?php
        $sql = "SELECT * FROM car WHERE idcar = '$idcar1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Car shop<small>Edit car</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="idbrand">Brand</label>
            <select name="idbrand" class="form-control">
                <?php
                $tb = $conn->query('select idbrand, brand from brand');
                while($row = $tb->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idbrand'] ?>"><?php echo $row['brand'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="idcolor">Color</label>
            <select name="idcolor" class="form-control">
                <?php
                $categories = $conn->query('select idcolor, color from color');
                while($row = $categories->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idcolor'] ?>"><?php echo $row['color'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="idcartype">Cartype</label>
            <select name="idcartype" class="form-control">
                <?php
                $categories = $conn->query('select idcartype, cartype from cartype');
                while($row = $categories->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idcartype'] ?>"><?php echo $row['cartype'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="carname">Carname</label>
            <input type="text" name="carname" class="form-control" value="<?php echo $line['carname']?>"  require>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" name="price" class="form-control" value="<?php echo $line['price']?>"  require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?><br>
</body>
</html>