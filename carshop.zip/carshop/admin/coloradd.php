<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $idcolor = $_POST['idcolor'];
    $color = $_POST['color'];

    // Prepare sql and bind parameters
    $sql = "insert into color (idcolor,  color ) values (?, ?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ss' , $idcolor , $color );
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: color.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Carshop: <small>Add Color</small></h1>
    

    <form method="post" class="form">
        <div class="form-group">
            <label for="idcolor">Color ID</label>
            <input type="text" name="idcolor" class="form-control" require>
        </div>
        <div class="form-group">
            <label for="color">Color</label>
            <input type="text" name="color" class="form-control" require>
        </div>
        <input class="btn btn-primary" type="submit" value="Save"> <a href="color.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>