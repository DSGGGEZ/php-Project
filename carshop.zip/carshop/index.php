<?php
    require('session.php');
    require('dbconnect.php');
    require('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$idcartype = isset($_GET['idcartype']) ? $_GET['idcartype'] : "";
$idbrand = isset($_GET['idbrand']) ? $_GET['idbrand'] : "";
if ($idcartype != "" && $idbrand != "") {
    $sql = "SELECT * FROM car INNER JOIN brand ON car.idbrand=brand.idbrand INNER JOIN color ON car.idcolor=color.idcolor INNER JOIN cartype ON car.idcartype=cartype.idcartype WHERE car.idcartype = '$idcartype' and car.idbrand = '$idbrand'";
}
else if ($idcartype != "") {
    $sql = "SELECT * FROM car INNER JOIN brand ON car.idbrand=brand.idbrand INNER JOIN color ON car.idcolor=color.idcolor INNER JOIN cartype ON car.idcartype=cartype.idcartype WHERE car.idcartype = '$idcartype'";
}
else if ($idbrand != "") {
    $sql = "SELECT * FROM car INNER JOIN brand ON car.idbrand=brand.idbrand INNER JOIN color ON car.idcolor=color.idcolor INNER JOIN cartype ON car.idcartype=cartype.idcartype WHERE car.idbrand = '$idbrand'";
}
else {
    $sql = "SELECT * FROM car INNER JOIN brand ON car.idbrand=brand.idbrand INNER JOIN color ON car.idcolor=color.idcolor INNER JOIN cartype ON car.idcartype=cartype.idcartype";
}
$results = $conn->query($sql);
?>

    <form method="get" class="form-inline">
        Brand:
        <select name="idbrand" class="form-control">
            <option value="">All</option>
            <?php
            $brand = $conn->query('select idbrand, brand from brand');
            while($row = $brand->fetch_assoc()) {
                ?>
                <option value="<?php echo $row['idbrand'] ?>"><?php echo $row['brand'] ?></option>
                <?php
            }
            ?>
        </select> &nbsp;
        Cartype: &nbsp;
        <select name="idcartype" class="form-control">
            <option value="">All</option>
            <?php
            $cartype = $conn->query('select idcartype, cartype from cartype');
            while($row = $cartype->fetch_assoc()) {
                ?>
                <option value="<?php echo $row['idcartype'] ?>"><?php echo $row['cartype'] ?></option>
                <?php
            }
            ?>
        </select> &nbsp;
        
        <input class="btn btn-primary" type="submit" value="Filter">
    </form>

    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Car</th>
                <th>Detail</th>
                <th>Price</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td style="width: 400px; height: 75px;">
                    <center><img src="images/car.png"  style="width: 150px; height: 125px; object-fit: cover;"></center><br>
                    <h3 class="text-center"><?php echo $row['carname'] ?></h3>
                </td>
                <td>
                    <h4><ul>
                        <li><?php echo $row['brand'] ?></li>
                        <li><?php echo $row['cartype'] ?></li>
                        <li><?php echo $row['color'] ?></li>
                    </ul></h4>
                </td>
                <td><h4><?php echo $row['price'] ?><b> Baht</b></h4></td>
                <td class="text-center">
                    <a href="scadd.php?idcar=<?php echo $row['idcar'] ?>" class="btn btn-sm btn btn-info">Buy
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>