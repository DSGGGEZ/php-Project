<?php
require('session.php');
require('dbconnect.php');
require('header.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Carshop</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$customername = isset($_GET['customername']) ? $_GET['customername'] : "";
if ($customername != "") {
    $sql = "SELECT * FROM sold_car LEFT JOIN car ON car.idcar=sold_car.idcar WHERE sold_car.customername = '$customername'";
}
else {
    $sql = "SELECT * FROM sold_car LEFT JOIN car ON car.idcar=sold_car.idcar ";
}
$results = $conn->query($sql);
?>

    <h1>Sold Car</h1>

    <form method="get" class="form-inline">
        Customer name:
        <input type="text" name="customername" class="form-control" placeholder="customer name">
        <input class="btn btn-primary" type="submit" value="Filter">
    </form>

    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Sold Car ID</th>
                <th>Customer Name</th>
                <th>Car</th>
                <th>Sold Date</th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['idsold_car'] ?></td>
                <td><?php echo $row['customername'] ?></td>
                <td><?php echo $row['carname'] ?></td>
                <td><?php echo $row['sold_date'] ?></td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>