<?php
session_start();

if (!isset($_SESSION['customer'])) {
    $_SESSION['customer'] = [];
}
