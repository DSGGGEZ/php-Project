<?php
    $conn->close();
?>
<hr>
<p class="text-center small">นึกถึงคอมแรง นึกถึง Thun shop</p>
</body>
</html>