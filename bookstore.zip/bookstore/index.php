<?php
require('session.php');
require('dbconnect.php');
require('header.php');

$sql = "select itemid, picture, detail, unitprice from tbproduct";
$results = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$bookname = isset($_GET['bookname']) ? $_GET['bookname'] : "";
if ($bookname != "") {
    $sql = "SELECT * FROM book WHERE book_name = '$bookname'";
}
else {
    $sql = "SELECT * FROM book";
}
    $results = $conn->query($sql);
?>
    <br>
    <form method="get" class="form-inline">
            Book name: &nbsp;
            <input type="text" class="form-control" name="bookname" placeholder="Book Name">
            <input class="btn btn-primary" type="submit" value="Filter">
        </form>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Book number</th>
                <th>Book name</th>
                <th>Book detail</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['book_number'] ?></td>
                <td><?php echo $row['book_name'] ?></td>
                <td><?php echo $row['book_details'] ?></td>
                <td><?php echo $row['status'] ?></td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
</body>
</html>

<?php
require('footer.php');
?>
</html>