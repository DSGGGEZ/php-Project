<?php
$conn->close();
?>
<hr>
<p class="text-center small">Love book love reading</p>
</body>
</html>