<?php
require('session.php');
require('dbconnect.php');
require('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
    $sql = "SELECT * FROM borrowing_book INNER JOIN customer ON borrowing_book.idcustomer=customer.idcustomer INNER JOIN book ON borrowing_book.book_number=book.book_number ORDER BY borrowing_book.borrow_date";
    $results = $conn->query($sql);
?>


    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Code</th>
                <th>Book number</th>
                <th>Customer ID</th>
                <th>Borrow date</th>
                <th>Deadline</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            if ($row['deadline']==date('Y-m-d')){
                $status = 'Late';
            }
            else{
                $status = 'Borrowing';
            }
            ?>
            <tr>
                <td><?php echo $row['verification_code'] ?></td>
                <td><?php echo $row['book_name'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['borrow_date'] ?></td>
                <td><?php echo $row['deadline'] ?></td>
                <td><?php echo $status ?></td>
                

                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>