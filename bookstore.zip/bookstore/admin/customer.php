<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$name = isset($_GET['name']) ? $_GET['name'] : "";
if ($name != "") {
    $sql = "SELECT * FROM customer WHERE name = '$name'";
}
else {
    $sql = "SELECT * FROM customer";
}
    $results = $conn->query($sql);
?>

    <h1>Bookstore Admin <small>customer</small></h1>
<h4><a href="index.php" >book</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer.php" >customer</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="borrow.php" >borrowed</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="return.php" >returned</a>
    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    <a href="customeradd.php" class="btn btn-primary pull-right">Register customer</a><br>
    <br>
    <form method="get" class="form-inline">
            Name: &nbsp;
            <input type="text" class="form-control" name="name" placeholder="Name">
            <input class="btn btn-primary" type="submit" value="Filter">
        </form>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Address</th>
                <th>City</th>
                <th>Zipcode</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['idcustomer'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['address'] ?></td>
                <td><?php echo $row['city'] ?></td>
                <td><?php echo $row['zipcode'] ?></td>
                <td class="text-center">
                    <a href="customeredit.php?idcustomer=<?php echo $row['idcustomer'] ?>" class="btn btn-sm btn btn-info">
                        <span class="glyphicon glyphicon-edit "></span>
                    <a href="customerdelete.php?idcustomer=<?php echo $row['idcustomer'] ?>" class="btn btn-sm btn btn-danger">
                        <span class="glyphicon glyphicon-trash "></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>