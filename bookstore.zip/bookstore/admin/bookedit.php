<?php
require('lock.php');
require('../dbconnect.php');

$book_number1 = $_GET['book_number'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the posted data
    $book_number = $_POST['book_number'];
    $book_name = $_POST['book_name'];
    $book_details = $_POST['book_details'];

    // Prepare sql and bind parameters
    $sql = "UPDATE book SET book_number = ? , book_name =? , book_details = ? WHERE book_number = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss', $book_number,$book_name,$book_details,$book_number1);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
    <?php
        $sql = "select * from book where book_number = '$book_number1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Bookstore:<small>Edit Book</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="name">Book number</label>
            <input type="text" name="book_number" class="form-control" value="<?php echo $line['book_number'] ?>">
        </div>
        <div class="form-group">
            <label for="address">Book name</label>
            <input type="text" name="book_name" class="form-control" value="<?php echo $line['book_name'] ?>">
        </div>
        <div class="form-group">
            <label for="city">Book detail</label>
            <input type="text" name="book_details" class="form-control" value="<?php echo $line['book_details'] ?>">
        </div>
        <input class="btn btn-primary" type="submit" value="Edit book"> 
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>