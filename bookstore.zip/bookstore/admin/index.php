<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
$bookname = isset($_GET['bookname']) ? $_GET['bookname'] : "";
if ($bookname != "") {
    $sql = "SELECT * FROM book WHERE book_name = '$bookname'";
}
else {
    $sql = "SELECT * FROM book";
}
    $results = $conn->query($sql);
?>

    <h1>Bookstore Admin <small>book</small></h1>
<h4><a href="index.php" >book</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer.php" >customer</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="borrow.php" >borrowed</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="return.php" >returned</a>
    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    <a href="bookadd.php" class="btn btn-primary pull-right">Add Book</a><br>
    <br>
    <form method="get" class="form-inline">
            Book name: &nbsp;
            <input type="text" class="form-control" name="bookname" placeholder="Book Name">
            <input class="btn btn-primary" type="submit" value="Filter">
        </form>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Book number</th>
                <th>Book name</th>
                <th>Book detail</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['book_number'] ?></td>
                <td><?php echo $row['book_name'] ?></td>
                <td><?php echo $row['book_details'] ?></td>
                <td><?php echo $row['status'] ?></td>
                <td class="text-center">
                    <a href="bookedit.php?book_number=<?php echo $row['book_number'] ?>" class="btn btn-sm btn btn-info">
                        <span class="glyphicon glyphicon-edit "></span>
                    <a href="bookdelete.php?book_number=<?php echo $row['book_number'] ?>" class="btn btn-sm btn btn-danger">
                        <span class="glyphicon glyphicon-trash "></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>