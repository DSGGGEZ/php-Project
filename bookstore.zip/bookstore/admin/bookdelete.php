<?php
require('lock.php');
require('../dbconnect.php');

$book_number = $_GET['book_number'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Prepare sql and bind parameters
    $sql = "delete from book where book_number = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('s', $book_number);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Bookstore:<small>Delete Book</small></h1>

    <?php
    $sql = "select book_name from book where book_number = $book_number";
    $book = $conn->query($sql);
    $row = $book->fetch_assoc();
    ?>
    <p>Are you sure you want to delete '<?php echo $row['book_name']; ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Delete">
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>