<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
    $sql = "SELECT * FROM returned_book INNER JOIN customer ON returned_book.idcustomer=customer.idcustomer INNER JOIN book ON returned_book.book_number=book.book_number";
    $results = $conn->query($sql);
?>

    <h1>Bookstore Admin <small>return</small></h1>
<h4><a href="index.php" >book</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer.php" >customer</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="borrow.php" >borrowed</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="return.php" >returned</a>
    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    
    <br>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Code</th>
                <th>Book number</th>
                <th>Customer ID</th>
                <th>Return date</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['verification_code'] ?></td>
                <td><?php echo $row['book_name'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['return_date'] ?></td>
                <td class="text-center">
                    <a href="returnedit.php?verification_code=<?php echo $row['verification_code'] ?>" class="btn btn-sm btn btn-info">
                        <span class="glyphicon glyphicon-edit "></span>
                    <a href="returndelete.php?verification_code=<?php echo $row['verification_code'] ?>" class="btn btn-sm btn btn-danger">
                        <span class="glyphicon glyphicon-trash "></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>