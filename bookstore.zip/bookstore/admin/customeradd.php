<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $idcustomer = $_POST['idcustomer'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $zipcode = $_POST['zipcode'];
    

    $sql = "INSERT INTO customer(idcustomer,name,address,city,zipcode) VALUES (?,?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sssss',$idcustomer,$name,$address,$city,$zipcode);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }
    header('Location: customer.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Bookstore:<small>Register Customer</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="idcustomer">Customer id</label>
            <input type="text" class="form-control" name="idcustomer" required>
        </div>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" name="name" required>
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" name="address" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="city">City</label>
            <input type="text" name="city" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="zipcode">Zipcode</label>
            <input type="text" name="zipcode" class="form-control" required>
        </div>
        <input class="btn btn-success" type="submit" value="ลงทะเบียน"> 
        <a href="customer.php" class="btn btn-default">ยกเลิก</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>