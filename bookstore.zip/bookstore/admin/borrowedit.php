<?php
require('lock.php');
require('../dbconnect.php');

$verification_code1 = $_GET['verification_code'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $verification_code = $_POST['verification_code'];
    $book_number = $_POST['book_number'];
    $idcustomer = $_POST['idcustomer'];
    $borrow_date = $_POST['borrow_date'];
    $deadline = $_POST['deadline'];

    $sql = "UPDATE borrowing_book SET verification_code =? , book_number =? , idcustomer = ?, borrow_date = ? , deadline = ? WHERE verification_code = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssssss',$verification_code,$book_number,$idcustomer,$borrow_date,$deadline,$verification_code1);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    header('Location: borrow.php');
    
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
    <?php
        $sql = "SELECT * FROM borrowing_book INNER JOIN customer ON borrowing_book.idcustomer=customer.idcustomer INNER JOIN book ON borrowing_book.book_number=book.book_number WHERE borrowing_book.verification_code = '$verification_code1'";
        $res = $conn->query($sql);
        $line = $res->fetch_assoc();
    ?>
    <h1>Bookstore<small>Edit Borrow</small></h1>
    
    <form method="post" class="form">
        <div class="form-group">
            <label for="verification_code">Verification code</label>
            <input type="text" class="form-control" name="verification_code" value=<?php echo $line['verification_code']?> placeholderrequired>
        </div>
        <div class="form-group">
            <label for="book_number">Book</label>
            <select name="book_number" class="form-control" value=<?php echo $line['book_name']?> >
                <?php
                $idplatform = $conn->query('select book_number, book_name from book');
                while($row = $idplatform->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['book_number'] ?>"><?php echo $row['book_name'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="idcustomer">Customer</label>
            <select name="idcustomer" class="form-control" value=<?php echo $line['name']?> >
                <?php
                $idplatform = $conn->query('select idcustomer, name from customer');
                while($row = $idplatform->fetch_assoc()) {
                    ?>
                    <option value="<?php echo $row['idcustomer'] ?>"><?php echo $row['name'] ?></option>
                    <?php
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="borrow_date">Borrow Date</label>
            <input type="date" name="borrow_date" class="form-control" value=<?php echo $line['borrow_date']?> required>
        </div>
        <div class="form-group">
            <label for="deadline">Deadline</label>
            <input type="date" name="deadline" class="form-control" value=<?php echo $line['deadline']?> required>
        </div>
        <input class="btn btn-success" type="submit" value="Add"> 
        <a href="borrow.php" class="btn btn-default">Cancel</a>
    </form>
    <?php
        $conn->close();
    ?>
</body>
</html>