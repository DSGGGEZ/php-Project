<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the posted data
    $book_number = $_POST['book_number'];
    $book_name = $_POST['book_name'];
    $book_details = $_POST['book_details'];

    // Prepare sql and bind parameters
    $sql = "insert into book (book_number, book_name, book_details) values (?, ?, ?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('sss', $book_number, $book_name ,$book_details);
    $result = $statement->execute();

    // Execute sql and check for failure
    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }

    // Redirect
    header('Location: index.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Bookstore: <small>Add Book</small></h1>

    <form method="post" class="form">
        <div class="form-group">
            <label for="book_number">Book number</label>
            <input type="text" name="book_number" class="form-control">
        </div>
        <div class="form-group">
            <label for="book_name">Book name</label>
            <input type="text" name="book_name" class="form-control">
        </div>
        <div class="form-group">
            <label for="book_details">Book detail</label>
            <input type="text" name="book_details" class="form-control">
        </div>
        <input class="btn btn-primary" type="submit" value="Save">
        <a href="index.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>