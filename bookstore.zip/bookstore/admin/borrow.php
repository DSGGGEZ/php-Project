<?php
require('lock.php');
require('../dbconnect.php');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">
<?php
    $sql = "SELECT * FROM borrowing_book INNER JOIN customer ON borrowing_book.idcustomer=customer.idcustomer INNER JOIN book ON borrowing_book.book_number=book.book_number";
    $results = $conn->query($sql);
?>

    <h1>Bookstore Admin <small>borrow</small></h1>
<h4><a href="index.php" >book</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer.php" >customer</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="borrow.php" >borrowed</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="return.php" >returned</a>
    <a href="logout.php" class="btn btn-danger pull-right" style="margin-left: 10px">Logout</a>
    <a href="borrowadd.php" class="btn btn-primary pull-right">Borrow</a><br>
    <br>
    <table class="table table-bordered" style="margin-top: 20px">
        <thead>
            <tr>
                <th>Code</th>
                <th>Book number</th>
                <th>Customer ID</th>
                <th>Borrow date</th>
                <th>Deadline</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php
        while($row = $results->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $row['verification_code'] ?></td>
                <td><?php echo $row['book_name'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['borrow_date'] ?></td>
                <td><?php echo $row['deadline'] ?></td>
                <td class="text-center">
                <a href="sendback.php?verification_code=<?php echo $row['verification_code'] ?>" class="btn btn-sm btn btn-info">
                        <span class="glyphicon glyphicon-calendar "></span>
                    <a href="borrowedit.php?verification_code=<?php echo $row['verification_code'] ?>" class="btn btn-sm btn btn-info">
                        <span class="glyphicon glyphicon-edit "></span>
                    <a href="borrowdelete.php?verification_code=<?php echo $row['verification_code'] ?>" class="btn btn-sm btn btn-danger">
                        <span class="glyphicon glyphicon-trash "></span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>

<?php
$conn->close();
?>
</body>
</html>