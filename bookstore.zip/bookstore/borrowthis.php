<?php
require('lock.php');
require('../dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $bb="SELECT * FROM borrowing_book WHERE verification_code='$verification_code'";
    $bor = $conn->query($bb);
    $row1 = $bor->fetch_assoc();

    $book_number = $row1['book_number'];
    $idcustomer = $row1['idcustomer'];
    $return_date = date('Y-m-d');

    $del = "delete from borrowing_book where verification_code = ?";
    $st = $conn->prepare($del);
    $st->bind_param('i', $verification_code);
    $res = $st->execute();

    $sql = "INSERT INTO returned_book(verification_code,book_number,idcustomer,return_date) VALUES (?,?,?,?)";
    $statement = $conn->prepare($sql);
    $statement->bind_param('ssss',$verification_code,$book_number,$idcustomer,$return_date);
    $result = $statement->execute();

    if (!$result) {
        die('Execute failed: ' . $statement->error);
    }
    header('Location: return.php');
    exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Bookstore</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body class="container">

    <h1>Bookstore<small>Return book</small></h1>


    <?php
    $sql = "select * from borrowing_book where verification_code = $verification_code";
    $name = $conn->query($sql);
    $row = $name->fetch_assoc();
    ?>
    <p>Return book code'<?php echo $row['verification_code'] ?>'?</p>

    <form method="post" class="form">
        <input class="btn btn-danger" type="submit" value="Return">
        <a href="borrow.php" class="btn btn-default">Cancel</a>
    </form>

<?php
$conn->close();
?>
</body>
</html>