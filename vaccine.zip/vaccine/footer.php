<?php
$conn->close();
?>
<hr>
<p class="text-center small">Take care</p>
</body>
</html>