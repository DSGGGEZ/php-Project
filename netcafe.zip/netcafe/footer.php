<?php
    $conn->close();
?>
<hr>
<p class="text-center small">NET Cafe คอมแรง คอมไว ไม่กระตุก</p>
</body>
</html>